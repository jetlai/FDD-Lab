﻿// Filename: 01-Outline.js
function Warning()
{
	window.alert("You have entered a non-smoking website!");
}
