vti_encoding:SR|utf8-nl
vti_author:SR|APIIT-MAIL\\chung.wei
vti_modifiedby:SR|APIIT-MAIL\\chung.wei
vti_timelastmodified:TR|11 Jul 2023 01:21:27 -0000
vti_timecreated:TR|11 Jul 2023 01:20:10 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|01-Outline.html
vti_nexttolasttimemodified:TW|11 Jul 2023 01:20:21 -0000
vti_cacheddtm:TX|11 Jul 2023 01:21:27 -0000
vti_filesize:IR|151
