vti_encoding:SR|utf8-nl
vti_author:SR|APIIT-MAIL\\chung.wei
vti_modifiedby:SR|APIIT-MAIL\\chung.wei
vti_timelastmodified:TR|25 Jul 2023 01:58:31 -0000
vti_timecreated:TR|25 Jul 2023 01:57:29 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|aboutus.html
vti_nexttolasttimemodified:TW|25 Jul 2023 01:57:57 -0000
vti_cacheddtm:TX|25 Jul 2023 01:58:31 -0000
vti_filesize:IR|880
