vti_encoding:SR|utf8-nl
vti_author:SR|APIIT-MAIL\\chung.wei
vti_modifiedby:SR|APIIT-MAIL\\chung.wei
vti_timelastmodified:TR|25 Jul 2023 02:12:47 -0000
vti_timecreated:TR|25 Jul 2023 02:10:30 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|events.html
vti_nexttolasttimemodified:TW|25 Jul 2023 02:10:38 -0000
vti_cacheddtm:TX|25 Jul 2023 02:12:47 -0000
vti_filesize:IR|737
