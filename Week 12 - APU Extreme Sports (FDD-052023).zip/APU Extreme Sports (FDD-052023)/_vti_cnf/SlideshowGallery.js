vti_encoding:SR|utf8-nl
vti_author:SR|APIIT-MAIL\\chung.wei
vti_modifiedby:SR|APIIT-MAIL\\chung.wei
vti_timelastmodified:TR|27 Jul 2023 08:37:46 -0000
vti_timecreated:TR|27 Jul 2023 08:37:32 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
vti_cacheddtm:TX|27 Jul 2023 08:37:46 -0000
vti_filesize:IR|3
vti_nexttolasttimemodified:TR|27 Jul 2023 08:37:32 -0000
