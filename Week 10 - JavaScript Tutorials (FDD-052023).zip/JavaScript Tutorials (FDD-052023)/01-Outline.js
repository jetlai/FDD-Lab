﻿/* External JavaScript file
   Filename: 01-Outline.js */
function Warning()
{
	window.alert("You must physical presence for attendance!");
}
